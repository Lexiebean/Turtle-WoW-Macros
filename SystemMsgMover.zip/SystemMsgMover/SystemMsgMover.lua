SystemMsgMover_ChatFrame_OnEvent = ChatFrame_OnEvent

function ChatFrame_OnEvent(event)

	if (event == "CHAT_MSG_SYSTEM") then
		ChatFrame3:AddMessage(arg1) --Change "3" to another number from 1 to 10 to move the message around. 1 is the default window where it normally is. 2 is usually the combat log. 3+ are usually custom windows.
		--return --remove the 2 "--" at the start of this line to hide the default system messages.
	end
	
  SystemMsgMover_ChatFrame_OnEvent(event);
end